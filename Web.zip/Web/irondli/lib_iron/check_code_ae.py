print("Коды буквы ӕ")
right_symbol = "ӕ"      #code - 1237
current_symbol = "c"
print(ord(right_symbol))
print(ord(current_symbol))
print(right_symbol.upper())
print(current_symbol.upper())


print("Коды апострофа")
right_symbol = "'"
current_symbol = "’"
print(ord(right_symbol))
print(ord(current_symbol))
