from class_sort_iron import dict_word

word = dict_word("хъӕд")
print(word.list())


s = dict_word("Дӕллагхъӕу")
print(s.list())





